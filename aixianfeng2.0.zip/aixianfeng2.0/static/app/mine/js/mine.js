$(function () {

    $("#order_payed_list").click(function () {

        window.open("/axf/orderlist/", target="_self");

    })

    $("#wait_pay_list").click(function () {

        window.open("/axf/orderlistwaitpay/", target="_self");

    })

})